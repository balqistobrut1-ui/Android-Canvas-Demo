# CART3R MLBB ESP Demo

Android Kotlin + Canvas offline visualization. This project draws simulated hero targets only; it does not connect to Mobile Legends, inspect game memory, hook a process, or reveal real player positions.

Features: skeleton/joints, 2D corner boxes, simulated distance labels, health bars, radius/FOV circle toggle, adjustable radius.

## Build on a phone using GitHub Actions
1. Create a GitHub repository.
2. Upload the complete contents of this folder, including `.github/workflows/android-build.yml`.
3. Open Actions and run **Build CART3R MLBB Demo APK**.
4. Download the `CART3R-MLBB-Demo-APK` artifact from the completed workflow run.

You can also open this project in Android Studio on a computer.
