package com.carter.mlbbdemo

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.min

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(8, 9, 14)) }
        val visual = MlbbDemoView(this)
        root.addView(visual, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(9))
            background = GradientDrawable().apply {
                setColor(Color.argb(238, 17, 18, 26))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.rgb(190, 45, 65))
            }
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
            }
        panel.addView(label("CART3R // MLBB ESP LAB", 15f, Color.rgb(255, 75, 95)))
        panel.addView(label("OFFLINE DEMO • SIMULATED HEROES", 9f, Color.LTGRAY).apply {
            setPadding(0, dp(3), 0, dp(6))
        })

        fun toggle(name: String, initial: Boolean, action: (Boolean) -> Unit) {
            panel.addView(CheckBox(this).apply {
                text = name
                textSize = 12f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 75, 95))
                isChecked = initial
                setOnCheckedChangeListener { _, checked -> action(checked) }
            })
        }
        toggle("Skeleton ESP", true) { visual.skeleton = it; visual.invalidate() }
        toggle("Player boxes", true) { visual.boxes = it; visual.invalidate() }
        toggle("Distance", true) { visual.distance = it; visual.invalidate() }
        toggle("Health bars", true) { visual.health = it; visual.invalidate() }
        toggle("Radius / FOV circle", true) { visual.radiusEnabled = it; visual.invalidate() }

        panel.addView(label("RADIUS SIZE", 10f, Color.LTGRAY))
        val radiusValue = label("180 dp", 10f, Color.rgb(255, 110, 125))
        panel.addView(radiusValue)
        panel.addView(SeekBar(this).apply {
            max = 280
            progress = 140
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    visual.radiusDp = (progress + 40).toFloat()
                    radiusValue.text = "${progress + 40} dp"
                    visual.invalidate()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })

        root.addView(panel, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(12), dp(16), dp(12), dp(12))
        })
        root.addView(label("DEMO ONLY — NOT CONNECTED TO MLBB", 9f, Color.LTGRAY).apply {
            setPadding(dp(9), dp(7), dp(9), dp(7))
            background = GradientDrawable().apply {
                setColor(Color.argb(200, 18, 18, 24)); cornerRadius = dp(8).toFloat()
            }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(16)
        })
        setContentView(root)
    }
}

private data class Hero(val x: Float, val y: Float, val hp: Int, val meters: Int, val name: String)

private class MlbbDemoView(context: android.content.Context) : View(context) {
    var skeleton = true
    var boxes = true
    var distance = true
    var health = true
    var radiusEnabled = true
    var radiusDp = 180f

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private val red = Color.rgb(255, 65, 85)
    private val green = Color.rgb(85, 240, 175)
    private val grid = Paint(3).apply { color = Color.rgb(25, 29, 39); strokeWidth = dp(1f) }
    private val boxPaint = Paint(3).apply { color = red; strokeWidth = dp(2f); style = Paint.Style.STROKE }
    private val bone = Paint(3).apply { color = green; strokeWidth = dp(2f); strokeCap = Paint.Cap.ROUND }
    private val joint = Paint(3).apply { color = Color.WHITE }
    private val txt = Paint(3).apply { color = Color.WHITE; textSize = dp(10f); typeface = Typeface.DEFAULT_BOLD }
    private val barBg = Paint(3).apply { color = Color.DKGRAY }
    private val barFg = Paint(3).apply { color = Color.rgb(65, 220, 125) }
    private val radiusPaint = Paint(3).apply {
        color = Color.argb(210, 255, 70, 95); style = Paint.Style.STROKE
        strokeWidth = dp(1.7f); pathEffect = android.graphics.DashPathEffect(floatArrayOf(dp(7f), dp(5f)), 0f)
    }
    private val heroes = listOf(
        Hero(.35f, .56f, 85, 6, "HERO 01"),
        Hero(.70f, .64f, 52, 12, "HERO 02"),
        Hero(.57f, .85f, 100, 3, "HERO 03")
    )

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(8, 9, 14))
        var x = 0f
        while (x < width) { c.drawLine(x, 0f, x, height.toFloat(), grid); x += dp(34f) }
        var y = 0f
        while (y < height) { c.drawLine(0f, y, width.toFloat(), y, grid); y += dp(34f) }

        val cx = width * .5f
        val cy = height * .58f
        if (radiusEnabled) {
            c.drawCircle(cx, cy, dp(radiusDp), radiusPaint)
            txt.color = red
            c.drawText("RADIUS / FOV • ${radiusDp.toInt()}dp", cx - dp(radiusDp), cy - dp(radiusDp) - dp(7f), txt)
        }

        val h = min(width, height) * .19f
        heroes.forEach { hero ->
            val centerX = hero.x * width
            val centerY = hero.y * height
            val w = h * .48f
            val r = RectF(centerX-w/2, centerY-h/2, centerX+w/2, centerY+h/2)
            if (boxes) cornerBox(c, r)
            if (skeleton) drawSkeleton(c, r)
            if (health) {
                val b = RectF(r.left-dp(7f), r.top, r.left-dp(3f), r.bottom)
                c.drawRoundRect(b, dp(2f), dp(2f), barBg)
                val f = hero.hp.coerceIn(0,100) / 100f
                c.drawRoundRect(RectF(b.left,b.bottom-b.height()*f,b.right,b.bottom),dp(2f),dp(2f),barFg)
            }
            if (distance) {
                txt.color = Color.WHITE
                c.drawText("${hero.name} • ${hero.meters}m", r.left, r.top-dp(7f), txt)
            }
        }
        txt.color = red
        c.drawText("SIMULATED HEROES: ${heroes.size}", dp(14f), height-dp(55f), txt)
    }

    private fun cornerBox(c: Canvas, r: RectF) {
        val l = r.width()*.24f
        val pts = arrayOf(
            floatArrayOf(r.left,r.top,1f,1f), floatArrayOf(r.right,r.top,-1f,1f),
            floatArrayOf(r.left,r.bottom,1f,-1f), floatArrayOf(r.right,r.bottom,-1f,-1f)
        )
        pts.forEach { p ->
            c.drawLine(p[0],p[1],p[0]+l*p[2],p[1],boxPaint)
            c.drawLine(p[0],p[1],p[0],p[1]+l*p[3],boxPaint)
        }
    }

    private fun drawSkeleton(c: Canvas, r: RectF) {
        fun p(x: Float,y: Float)=floatArrayOf(r.left+x*r.width(),r.top+y*r.height())
        val head=p(.5f,.13f); val neck=p(.5f,.26f); val sl=p(.22f,.31f); val sr=p(.78f,.31f)
        val el=p(.10f,.48f); val er=p(.90f,.48f); val hl=p(.06f,.62f); val hr=p(.94f,.62f)
        val pl=p(.36f,.58f); val pr=p(.64f,.58f); val pelvis=p(.5f,.59f)
        val kl=p(.29f,.80f); val kr=p(.71f,.80f); val fl=p(.20f,.98f); val fr=p(.80f,.98f)
        listOf(neck to sl,neck to sr,neck to pelvis,sl to el,el to hl,sr to er,er to hr,
            pl to pelvis,pelvis to pr,pl to kl,kl to fl,pr to kr,kr to fr).forEach {
            c.drawLine(it.first[0],it.first[1],it.second[0],it.second[1],bone)
        }
        c.drawCircle(head[0],head[1],min(r.width(),r.height())*.085f,boxPaint)
        listOf(neck,sl,sr,el,er,hl,hr,pl,pr,pelvis,kl,kr,fl,fr).forEach {
            c.drawCircle(it[0],it[1],dp(2f),joint)
        }
    }
}
